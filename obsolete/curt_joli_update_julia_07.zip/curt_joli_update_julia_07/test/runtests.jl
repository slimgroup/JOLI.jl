using Test
using JOLI
using InplaceOps
using LinearAlgebra
using Random

jo_type_mismatch_error_set(false)
verbose=false

# write your own tests here
total_time = @time begin
include("test_joMatrixSingle.jl")
include("test_joMatrixProduct.jl")
include("test_joMatrixSum.jl")
include("test_joMatrixDifference.jl")
include("test_joLinearFunctionSingle.jl")
include("test_joLinearFunctionProduct.jl")
include("test_joLinearFunctionSum.jl")
include("test_joLinearFunctionDifference.jl")
include("test_joLinearFunctionAndMatrixProduct.jl")
include("test_joLinearFunctionAndMatrixSum.jl")
include("test_joLinearFunctionAndMatrixDifference.jl")
include("test_joInplaceOps.jl")
include("test_joMatrixCons.jl")
include("test_joKron.jl")
include("test_joCoreBlock.jl")
include("test_joBlock.jl")
include("test_joBlockDiag.jl")
include("test_joDict.jl")
include("test_joStack.jl")
include("test_joDFT.jl")
include("test_joDCT.jl")
include("test_joCurvelet2D.jl")
include("test_joCurvelet2DnoFFT.jl")
include("test_joExtend.jl")
end 
println("\nTest Total elapsed time: ",round(total_time,1),"s")

mn=rand(3:7)
tsname="Inplace"
@testset "$tsname" begin

verbose && println("$tsname - ($mn,$mn)")
@testset begin
    DDT=Float64
    RDT=Float64
    
    construct_op = [a->joInplaceMatrix(a,is_invertible=true),
                    b->joInplaceLinearFunctionAll(size(b,1),size(b,2),(out,v)->LinearAlgebra.mul!(out,b,v),
                            (out,v)->LinearAlgebra.mul!(out,transpose(b),v),
                            (out,v)->LinearAlgebra.mul!(out,adjoint(b),v),
                            (out,v)->LinearAlgebra.mul!(out,conj(b),v),
                            (out,v)->LinearAlgebra.ldiv!(out,factorize(b),v),
                            (out,v)->LinearAlgebra.ldiv!(out,transpose(factorize(b)),v),
                            (out,v)->LinearAlgebra.ldiv!(out,adjoint(factorize(b)),v),
                            (out,v)->LinearAlgebra.ldiv!(out,conj(factorize(b)),v),eltype(b),eltype(b),
                            multi_vec=true,inv_multi_vec=true)]
    for operator in construct_op    
        a = rand(mn,mn)
        A=operator(a)

        x=rand(DDT,mn)
        mx=rand(DDT,mn,mn)
        Y = Z = zeros(RDT,mn)
        MY = MZ = zeros(RDT,mn,mn)

        y = a*x
        @! Y=A*x
        @test Y≈y
        @test Y==Z

        my = a*mx
        @! MY=A*mx
        @test MY≈my
        @test MY==MZ

        x=rand(RDT,mn)
        mx=rand(RDT,mn,mn)
        Y = Z = zeros(DDT,mn)
        MY = MZ = zeros(DDT,mn,mn)

        y=transpose(a)*x
        my=transpose(a)*mx
        @! Y=transpose(A)*x
        @test Y≈y
        @test Y==Z

        @! MY=transpose(A)*mx
        @test MY≈my
        @test MY==MZ

        x=rand(RDT,mn)
        mx=rand(RDT,mn,mn)
        Y = Z = zeros(DDT,mn)
        MY = MZ = zeros(DDT,mn,mn)

        y=a'*x
        my=a'*mx
        @! Y=A'*x
        @test Y≈y
        @test Y==Z
        @! MY=A'*mx
        @test MY≈my
        @test MY==MZ

        x=rand(RDT,mn)
        mx=rand(RDT,mn,mn)
        Y = Z = zeros(DDT,mn)
        MY = MZ = zeros(DDT,mn,mn)

        y=a\x
        my=a\mx
        @! Y=A\x
        @test Y≈y
        @test Y==Z
        @! MY=A\mx
        @test MY≈my

        x=rand(DDT,mn)
        mx=rand(DDT,mn,mn)
        Y = Z = zeros(RDT,mn)
        MY = MZ = zeros(RDT,mn,mn)
        
        y=transpose(a)\x
        my=transpose(a)\mx
        @! Y=transpose(A)\x
        @test Y≈y
        @test Y==Z
        @! MY=transpose(A)\mx
        @test MY≈my
        @test MY==MZ

        x=rand(RDT,mn)
        mx=rand(RDT,mn,mn)
        Y = Z = zeros(DDT,mn)
        MY = MZ = zeros(DDT,mn,mn)

        y=a'\x
        my=a'\mx
        @! Y=A'\x
        @test Y≈y
        @test Y==Z
        @! MY=A'\mx
        @test MY≈my
        @test MY==MZ
    end
end


end

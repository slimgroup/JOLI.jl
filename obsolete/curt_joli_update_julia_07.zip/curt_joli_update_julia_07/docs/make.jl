using Documenter, JOLI

makedocs(
    modules = [JOLI]
)

#deploydocs(
#    target = "tmp",
#    repo = "github.com/JOLI.jl.git"
#)

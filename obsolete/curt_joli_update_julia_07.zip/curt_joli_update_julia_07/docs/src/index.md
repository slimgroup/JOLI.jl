# JOLI reference

```@contents
Depth = 3
```

## Functions
```@autodocs
Modules = [JOLI]
Private = false
Order = [:function]
```

## Macros

```@autodocs
Modules = [JOLI]
Private = false
Order = [:macro]
```

## Types
```@autodocs
Modules = [JOLI]
Private = false
Order = [:type]
```
## Index

```@index
```

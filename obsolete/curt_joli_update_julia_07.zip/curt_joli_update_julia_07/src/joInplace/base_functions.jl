conj(A::joAbstractInplaceLinearOperator{DDT,RDT}) where {DDT,RDT} =
joInplaceLinearFunctionAll(A.m, A.n, 
                      A.fop_C, A.fop_CT, A.fop_T, A.fop,
                      A.iop_C, A.iop_CT, A.iop_T, A.iop,
                      DDT,RDT,multi_vec=A.multi_vec,inv_multi_vec=A.inv_multi_vec)

# transpose(jo)
transpose(A::joAbstractInplaceLinearOperator{DDT,RDT}) where {DDT,RDT} =
  joInplaceLinearFunctionAll(A.n, A.m, 
                      A.fop_T, A.fop, A.fop_C, A.fop_CT,
                      A.iop_T, A.iop, A.iop_C, A.iop_CT,
                      RDT,DDT,
                      name="transpose($(A.name))",
                      multi_vec=A.multi_vec,inv_multi_vec=A.inv_multi_vec)

# adjoint(jo)
adjoint(A::joAbstractInplaceLinearOperator{DDT,RDT}) where {DDT,RDT} =
joInplaceLinearFunctionAll(A.n, A.m, 
                      A.fop_CT, A.fop_C, A.fop, A.fop_T,
                      A.iop_CT, A.iop_C, A.iop, A.iop_T,
                      RDT,DDT,
                      name="adjoint($(A.name))",
                      multi_vec=A.multi_vec,inv_multi_vec=A.inv_multi_vec)




function wrap_inplace_func(f::Function, out_datatype::DataType, size_out::Integer)
    function wrapped_func(x)
        output = Matrix{out_datatype}(undef, size_out,size(x,2))
        return f(output,x)
    end
    return x->wrapped_func(x)
end

# Convert an inplace linear operator into a non-inplace linear operator
function wrap_inplace_op(A::joAbstractInplaceLinearOperator{DDT,RDT}) where {DDT,RDT}
    m,n = size(A)
    if hasinverse(A)
        return joLinearFunctionAll(m,n,
            wrap_inplace_func(A.fop, RDT, m),
            wrap_inplace_func(A.fop_T, RDT, m),
            wrap_inplace_func(A.fop_CT, RDT, m),
            wrap_inplace_func(A.fop_C, RDT, m),
            wrap_inplace_func(A.iop, DDT, m),
            wrap_inplace_func(A.iop_T, DDT, m),
            wrap_inplace_func(A.iop_CT, DDT, m),
            wrap_inplace_func(A.iop_C, DDT, m),
            DDT, RDT,
            name="$(A.name)"
            )
    else
        return joLinearFunctionAll(m,n,
            wrap_inplace_func(A.fop, RDT, m),
            wrap_inplace_func(A.fop_T, RDT, m),
            wrap_inplace_func(A.fop_CT, RDT, m),
            wrap_inplace_func(A.fop_C, RDT, m),
            @joNF, @joNF, @joNF, @joNF,
            DDT, RDT,
            name="$(A.name)"
            )
    end
end

wrap_inplace_op(A::joAbstractLinearOperator{DDT,RDT}) where {DDT, RDT} = A


function *(A::joAbstractInplaceLinearOperator{CDT,ARDT},B::joAbstractInplaceLinearOperator{BDDT,CDT}) where {ARDT,BDDT,CDT}
    return wrap_inplace_op(A)*wrap_inplace_op(B)
end

function *(A::joAbstractLinearOperator{CDT,ARDT},B::joAbstractInplaceLinearOperator{BDDT,CDT}) where {ARDT,BDDT,CDT}
    return A*wrap_inplace_op(B)
end

function *(A::joAbstractInplaceLinearOperator{CDT,ARDT},B::joAbstractLinearOperator{BDDT,CDT}) where {ARDT,BDDT,CDT}
    return wrap_inplace_op(A)*B
end



function *(a::Number,A::joAbstractInplaceLinearOperator{ADDT,ARDT}) where {ADDT,ARDT}
    if hasinverse(A)
        return joInplaceLinearOperator{ADDT,ARDT}("(N*"*A.name*")",A.m,A.n,
        (out,v)->jo_convert(ARDT,LinearAlgebra.mul!(out,A,a*v),false),
        (out,v)->jo_convert(ADDT,LinearAlgebra.mul!(out,transpose(A),a*v),false),
        (out,v)->jo_convert(ADDT,LinearAlgebra.mul!(out,A',conj(a)*v),false),
        (out,v)->jo_convert(ARDT,LinearAlgebra.mul!(out,conj(A),conj(a)*v),false),
        (out,v)->jo_convert(ARDT,LinearAlgebra.ldiv!(out,A,(1/a)*v),false),
        (out,v)->jo_convert(ARDT,LinearAlgebra.ldiv!(out,transpose(A),(1/a)*v),false),
        (out,v)->jo_convert(ARDT,LinearAlgebra.ldiv!(out,A',conj(1/a)*v),false),
        (out,v)->jo_convert(ARDT,LinearAlgebra.ldiv!(out,conj(A),conj(1/a)*v),false),
    )
    else
        return joInplaceLinearOperator{ADDT,ARDT}("(N*"*A.name*")",A.m,A.n,
        (out,v)->jo_convert(ARDT,LinearAlgebra.mul!(out,A,a*v),false),
        (out,v)->jo_convert(ADDT,LinearAlgebra.mul!(out,transpose(A),a*v),false),
        (out,v)->jo_convert(ADDT,LinearAlgebra.mul!(out,A',conj(a)*v),false),
        (out,v)->jo_convert(ARDT,LinearAlgebra.mul!(out,conj(A),conj(a)*v),false),
        @joNF, @joNF, @joNF, @joNF
    )
    end
end

function LinearAlgebra.mul!(output::Union{AbstractMatrix{mvDT}, AbstractVector{mvDT}}, A::joAbstractInplaceLinearOperator{ADDT,ARDT}, mv::Union{AbstractMatrix{mvDT}, AbstractVector{mvDT}}) where {ADDT,ARDT,mvDT<:Number}
    A.m == size(mv,1) || throw(joMatrixException("shape mismatch"))
    jo_check_type_match(ARDT,mvDT,join(["RDT for *(jo,mvec):",A.name,typeof(A),mvDT]," / "))
    if A.multi_vec       
        A.fop(output,mv)            
    else
        for i=1:size(mv,2)
            A.fop(output[:,i], mv[:,i])
        end        
    end
    return output
end

function LinearAlgebra.ldiv!(output::Union{AbstractMatrix{mvDT}, AbstractVector{mvDT}}, A::joAbstractInplaceLinearOperator{ADDT,ARDT}, mv::Union{AbstractMatrix{mvDT}, AbstractVector{mvDT}}) where {ADDT,ARDT,mvDT<:Number}
    A.m == size(mv,1) || throw(joMatrixException("shape mismatch"))
    jo_check_type_match(ARDT,mvDT,join(["RDT for \\(jo,mvec):",A.name,typeof(A),mvDT]," / "))
    if hasinverse(A)
        if A.inv_multi_vec       
            A.iop(output,mv)            
        else
            for i=1:size(mv,2)
                A.iop(output[:,i], mv[:,i])
            end
        end
    else
        throw(joMatrixException("\\(jo,Vector) not supplied"))
    end
    return output
end


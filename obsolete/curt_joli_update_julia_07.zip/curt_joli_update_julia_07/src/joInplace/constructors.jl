export joInplaceLinearFunctionAll, joInplaceMatrix

function joInplaceMatrix(array::AbstractMatrix{EDT};
    DDT::DataType=EDT,RDT::DataType=promote_type(EDT,DDT),name::String="joInplaceMatrix",is_invertible::Bool=false) where {EDT}
    if is_invertible
        factorized_array = LinearAlgebra.factorize(array)
        ldiv = (out,v)->LinearAlgebra.ldiv!(out,factorized_array,v)
        ldiv_transpose = (out,v)->LinearAlgebra.ldiv!(out,transpose(factorized_array),v)
        ldiv_adjoint = (out,v)->LinearAlgebra.ldiv!(out,adjoint(factorized_array),v)
        ldiv_conj = (out,v)->LinearAlgebra.ldiv!(out,conj(factorized_array),v)
    else
        ldiv = @joNF
        ldiv_transpose = @joNF
        ldiv_adjoint = @joNF
        ldiv_conj = @joNF
    end
    return joInplaceMatrix{DDT,RDT}(name,size(array,1),size(array,2),
        array, true, true,
        (out,v)->LinearAlgebra.mul!(out,array,v),
        (out,v)->LinearAlgebra.mul!(out,transpose(array),v),
        (out,v)->LinearAlgebra.mul!(out,adjoint(array),v),
        (out,v)->LinearAlgebra.mul!(out,conj(array),v),
        ldiv,
        ldiv_transpose,
        ldiv_adjoint,
        ldiv_conj
        )
end

function joInplaceLinearFunctionAll(m::Integer,n::Integer,
    fop::Function,fop_T::Union{Function,Nothing},fop_CT::Union{Function,Nothing},fop_C::Union{Function,Nothing},
    iop::Union{Function,Nothing},iop_T::Union{Function,Nothing},iop_CT::Union{Function,Nothing},iop_C::Union{Function,Nothing},
    DDT::DataType,RDT::DataType=DDT;
    multi_vec::Bool=false,inv_multi_vec::Bool=false,
    name::String="joInplaceLinearFunctionAll") 
    return joInplaceLinearFunction{DDT,RDT}(name,m,n,
        multi_vec, inv_multi_vec,
        fop,fop_T,fop_CT,fop_C,
        iop,iop_T,iop_CT,iop_C
    )
end
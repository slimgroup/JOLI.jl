export joAbstractInplaceLinearOperator, joInplaceLinearOperator, joInplaceMatrix

abstract type joAbstractInplaceLinearOperator{DDT<:Number,RDT<:Number} <: joAbstractLinearOperator{DDT,RDT} end

struct joInplaceLinearFunction{DDT<:Number, RDT<:Number} <: joAbstractInplaceLinearOperator{DDT,RDT}
    name::String
    m::Integer
    n::Integer
    multi_vec::Bool
    inv_multi_vec::Bool    
    fop::Function    # forward
    fop_T::Function  # transpose
    fop_CT::Function # conj transpose
    fop_C::Function  # conj
    iop::Union{Function,Nothing}
    iop_T::Union{Function,Nothing}
    iop_CT::Union{Function,Nothing}
    iop_C::Union{Function,Nothing}
end

struct joInplaceMatrix{DDT<:Number, RDT<:Number} <: joAbstractInplaceLinearOperator{DDT,RDT}
    name::String
    m::Integer
    n::Integer
    mat::Array{DDT,2}
    multi_vec::Bool
    inv_multi_vec::Bool    
    fop::Function    # forward
    fop_T::Function  # transpose
    fop_CT::Function # conj transpose
    fop_C::Function  # conj
    iop::Union{Function,Nothing}
    iop_T::Union{Function,Nothing}
    iop_CT::Union{Function,Nothing}
    iop_C::Union{Function,Nothing}
end

############################################################
# joMatrix #################################################
############################################################

export joMatrix, joMatrixException

# type definition
"""
joMatrix type

# TYPE PARAMETERS
- DDT::DataType : domain DataType
- RDT::DataType : range DataType

# FIELDS
- name::String : given name
- m::Integer : # of rows
- n::Integer : # of columns
- fop::Function : forward matrix
- fop_T::Function : transpose matrix
- fop_CT::Function : conj transpose matrix
- fop_C::Function : conj matrix
- iop::Union{Function,Nothing} : inverse for fop
- iop_T::Union{Function,Nothing} : inverse for fop_T
- iop_CT::Union{Function,Nothing} : inverse for fop_CT
- iop_C::Union{Function,Nothing} : inverse for fop_C

"""
struct joMatrix{DDT<:Number,RDT<:Number} <: joAbstractLinearOperator{DDT,RDT}
    name::String
    m::Integer
    n::Integer
    mat::Array{DDT,2}
    multi_vec::Bool
    inv_multi_vec::Bool    
    fop::Function    # forward
    fop_T::Function  # transpose
    fop_CT::Function # conj transpose
    fop_C::Function  # conj
    iop::Union{Function,Nothing}
    iop_T::Union{Function,Nothing}
    iop_CT::Union{Function,Nothing}
    iop_C::Union{Function,Nothing}
end

# type exception
mutable struct joMatrixException <: Exception
    msg :: String
end


############################################################
# joKron ###################################################
############################################################

export joKron, joKronException

# type definition
struct joKron{DDT,RDT} <: joAbstractLinearOperator{DDT,RDT}
    name::String
    m::Integer
    n::Integer
    l::Integer
    ms::Vector{Integer}
    ns::Vector{Integer}
    flip::Bool
    fop::Vector{joAbstractLinearOperator}
    fop_T::Vector{joAbstractLinearOperator}
    fop_CT::Vector{joAbstractLinearOperator}
    fop_C::Vector{joAbstractLinearOperator}
    iop::Union{Function, Nothing}
    iop_T::Union{Function, Nothing}
    iop_CT::Union{Function, Nothing}
    iop_C::Union{Function, Nothing}
end

# type exception
mutable struct joKronException <: Exception
    msg :: String
end


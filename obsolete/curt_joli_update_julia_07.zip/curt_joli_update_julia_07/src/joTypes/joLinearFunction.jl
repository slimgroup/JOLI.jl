############################################################
# joLinearFunction #########################################
############################################################

export joLinearFunction, joLinearFunctionException

# type definition
"""
joLinearFunction type

# TYPE PARAMETERS
- DDT::DataType : domain DataType
- RDT::DataType : range DataType

# FIELDS
- name::String : given name
- m::Integer : # of rows
- n::Integer : # of columns
- fop::Function : forward function
- fop_T::Union{Function,Nothing} : transpose function
- fop_CT::Union{Function,Nothing} : conj transpose function
- fop_C::Union{Function,Nothing} : conj function
- fMVok : whether fops are rady to handle mvec
- iop::Union{Function,Nothing} : inverse for fop
- iop_T::Union{Function,Nothing} : inverse for fop_T
- iop_CT::Union{Function,Nothing} : inverse for fop_CT
- iop_C::Union{Function,Nothing} : inverse for fop_C
- iMVok::Bool : whether iops are rady to handle mvec

"""
struct joLinearFunction{DDT<:Number,RDT<:Number} <: joAbstractLinearOperator{DDT,RDT}
    name::String
    m::Integer
    n::Integer
    multi_vec::Bool
    inv_multi_vec::Bool
    fop::Function              # forward
    fop_T::Union{Function,Nothing}  # transpose
    fop_CT::Union{Function,Nothing} # conj transpose
    fop_C::Union{Function,Nothing}  # conj
    iop::Union{Function,Nothing}
    iop_T::Union{Function,Nothing}
    iop_CT::Union{Function,Nothing}
    iop_C::Union{Function,Nothing}
end

# type exception
mutable struct joLinearFunctionException <: Exception
    msg :: String
end


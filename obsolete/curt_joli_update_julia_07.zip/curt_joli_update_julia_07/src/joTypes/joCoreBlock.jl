############################################################
# joCoreBlock ##############################################
############################################################

export joCoreBlock, joCoreBlockException

# type definition
struct joCoreBlock{DDT,RDT} <: joAbstractLinearOperator{DDT,RDT}
    name::String
    m::Integer
    n::Integer
    l::Integer
    ms::Vector{Integer}
    ns::Vector{Integer}
    mo::Vector{Integer}
    no::Vector{Integer}
    ws::Vector{Number}
    fop::Vector{joAbstractLinearOperator}
    fop_T::Vector{joAbstractLinearOperator}
    fop_CT::Vector{joAbstractLinearOperator}
    fop_C::Vector{joAbstractLinearOperator}
    iop::Union{Function, Nothing}
    iop_T::Union{Function, Nothing}
    iop_CT::Union{Function, Nothing}
    iop_C::Union{Function, Nothing}
end

# type exception
mutable struct joCoreBlockException <: Exception
    msg :: String
end


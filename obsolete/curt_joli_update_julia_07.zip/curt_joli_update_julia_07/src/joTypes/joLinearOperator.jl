############################################################
# joLinearOperator #########################################
############################################################

export joLinearOperator, joLinearOperatorException

# type definition
"""
    joLinearOperator is glueing type & constructor

    !!! Do not use it to create the operators
    !!! Use joMatrix and joLinearFunction constructors

"""
struct joLinearOperator{DDT<:Number,RDT<:Number} <: joAbstractLinearOperator{DDT,RDT}
    name::String
    m::Integer
    n::Integer
    fop::Function              # forward
    fop_T::Union{Function,Nothing}  # transpose
    fop_CT::Union{Function,Nothing} # conj transpose
    fop_C::Union{Function,Nothing}  # conj
    iop::Union{Function,Nothing}
    iop_T::Union{Function,Nothing}
    iop_CT::Union{Function,Nothing}
    iop_C::Union{Function,Nothing}
end

# type exception
struct joLinearOperatorException <: Exception
    msg :: String
end


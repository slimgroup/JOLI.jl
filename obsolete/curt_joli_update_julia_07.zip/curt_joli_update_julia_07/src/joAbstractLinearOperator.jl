############################################################
# joAbstractLinearOperator #################################
############################################################

# includes
include("joAbstractLinearOperator/constructors.jl")
include("joAbstractLinearOperator/base_functions.jl")
include("joAbstractLinearOperator/extra_functions.jl")

############################################################
## joAbstractLinearOperator - overloaded LinearAlgebra functions

# eltype(jo)
eltype(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = promote_type(DDT,RDT)

# deltype(jo)
deltype(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = DDT

# reltype(jo)
reltype(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = RDT

# show(jo)
show(A::joAbstractLinearOperator) = println((typeof(A),A.name,A.m,A.n))

# showall(jo)
showall(A::joAbstractLinearOperator) = println((typeof(A),A.name,A.m,A.n))

# display(jo)
display(A::joAbstractLinearOperator) = showall(A)

# size(jo)
size(A::joAbstractLinearOperator) = A.m,A.n

# size(jo,1/2)
function size(A::joAbstractLinearOperator,ind::Integer)
    if ind==1
		return A.m
	elseif ind==2
		return A.n
	else
		throw(joAbstractLinearOperatorException("invalid index"))
	end
end

# length(jo)
length(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = A.m*A.n

# full(jo)
full(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = A*Matrix{DDT}(one(DDT)*SparseArrays.I,A.n,A.n)

# norm(jo)
LinearAlgebra.norm(A::joAbstractLinearOperator{DDT,RDT},p::Real=2) where {DDT,RDT} = LinearAlgebra.norm(elements(A),p)

# real(jo)
function real(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT}
    throw(joAbstractLinearOperatorException("real(jo) not implemented"))
end
joReal(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = real(A)

# imag(jo)
function imag(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT}
    throw(joAbstractLinearOperatorException("imag(jo) not implemented"))
end
joImag(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = imag(A)

# conj(jo)
joConj(A::joAbstractLinearOperator) = conj(A)
conj(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} =
  joLinearFunctionAll(A.m, A.n, 
                      A.fop_C, A.fop_CT, A.fop_T, A.fop,
                      A.iop_C, A.iop_CT, A.iop_T, A.iop,
                      DDT,RDT,multi_vec=A.multi_vec,inv_multi_vec=A.inv_multi_vec)

# transpose(jo)
transpose(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} =
  joLinearFunctionAll(A.n, A.m, 
                      A.fop_T, A.fop, A.fop_C, A.fop_CT,
                      A.iop_T, A.iop, A.iop_C, A.iop_CT,
                      RDT,DDT,
                      name="transpose($(A.name))",
                      multi_vec=A.multi_vec,inv_multi_vec=A.inv_multi_vec)

# adjoint(jo)
adjoint(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} =
  joLinearFunctionAll(A.n, A.m, 
                      A.fop_CT, A.fop_C, A.fop, A.fop_T,
                      A.iop_CT, A.iop_C, A.iop, A.iop_T,
                      RDT,DDT,
                      name="adjoint($(A.name))",
                      multi_vec=A.multi_vec,inv_multi_vec=A.inv_multi_vec)



# isreal(jo)
isreal(A :: joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} = (DDT<:Real && RDT<:Real)

# issymmetric(jo)
issymmetric(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} =
    (A.m == A.n && (LinearAlgebra.norm(elements(A)-elements(A')) < joTol))

# ishermitian(jo)
ishermitian(A::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT} =
    (A.m == A.n && (LinearAlgebra.norm(elements(A)-elements(A')) < joTol))


function *(A::joAbstractLinearOperator{ADDT,ARDT}, mv::Union{AbstractMatrix{mvDT}, AbstractVector{mvDT}}) where {ADDT,ARDT,mvDT<:Number}
    A.n == size(mv,1) || throw(joMatrixException("shape mismatch: $(A.m) x $(A.n) operator but $(size(mv,1)) x $(size(mv,2)) input"))
    jo_check_type_match(ADDT,mvDT,join(["DDT for *(jo,mvec):",A.name,typeof(A),mvDT]," / "))
    if A.multi_vec
        MV = A.fop(mv)
        jo_check_type_match(ARDT,eltype(MV),join(["RDT from *(jo,mvec):",A.name,typeof(A),eltype(MV)]," / "))
    else
        MV = Matrix{ARDT}(undef, A.m, size(mv,2))
        for i=1:size(mv,2)
            y = A.fop(mv[:,i])
            MV[:,i] = y
        end
    end
    return MV
end

function \(A::joAbstractLinearOperator{ADDT,ARDT}, mv::Union{AbstractMatrix{mvDT}, AbstractVector{mvDT}}) where {ADDT,ARDT,mvDT<:Number}
    A.m == size(mv,1) || throw(joMatrixException("shape mismatch"))
    jo_check_type_match(ARDT,mvDT,"RDT for \\(jo,mvec): $(A.name) || $(typeof(A)) || $(mvDT)")
    if hasinverse(A)
        if A.inv_multi_vec          
            MV = A.iop(mv)            
        else
            MV = Matrix{ADDT}(undef, A.n, size(mv,2))
            for i=1:size(mv,2)
                y = A.iop(mv[:,i])
                MV[:,i] = y
            end
        end
    else
        throw(joMatrixException("\\(jo,Vector) not supplied"))
    end
    return MV
end

function *(A::joAbstractLinearOperator{CDT,ARDT},B::joAbstractLinearOperator{BDDT,CDT}) where {ARDT,BDDT,CDT}
    size(A,2) == size(B,1) || throw(joAbstractLinearOperatorException("shape mismatch: trying to multiply a $(A.m) x $(A.n) operator with a $(B.m) x $(B.n) operator"))
    if hasinverse(A) & hasinverse(B)
        return joLinearFunctionAll(size(A,1),size(B,2),
            v->A*(B*v),
            v->transpose(B)*(transpose(A)*v),
            v->B'*(A'*v),
            v->conj(A)*(conj(B)*v),
            v->B\(A\v),             
            v->transpose(A)\(transpose(B)\v),
            v->(A')\(B'\v),
            v->conj(B)\(conj(A)\v), 
            BDDT, ARDT, 
            multi_vec=(A.multi_vec & B.multi_vec),
            inv_multi_vec=(A.inv_multi_vec & B.inv_multi_vec),
            name="$(A.name)*$(B.name)")        
    else
        return joLinearFunctionCT(size(A,1),size(B,2),
            v1->A*(B*v1),
            v2->transpose(B)*(transpose(A)*v2),
            v3->B'*(A'*v3),
            v4->conj(A)*(conj(B)*v4),
            BDDT, ARDT,
            multi_vec=(A.multi_vec & B.multi_vec),
            name="$(A.name)*$(B.name)")
    end    
end


function *(a::Number,A::joAbstractLinearOperator{ADDT,ARDT}) where {ADDT,ARDT}
    if hasinverse(A)
        return joLinearFunctionAll(A.m,A.n,
            v->a*(A*v),
            v->transpose(A)*(a*v),
            v->A'*(conj(a)*v),
            v->conj(a)*(conj(A)*v),
            v->A\((1/a)*v),
            v->(1/a)*(transpose(A)\v),
            v->1/conj(a)*(A'\v),
            v->conj(A)\(1/conj(a)*v),
            ADDT,ARDT,
            multi_vec=A.multi_vec,
            inv_multi_vec=A.inv_multi_vec,
            name="(N*$(A.name))"
        )
    else
        return joLinearFunctionCT(A.m,A.n,
            v->a*(A*v),
            v->transpose(A)*(a*v),
            v->A'*(conj(a)*v),
            v->conj(a)*(conj(A)*v),            
            ADDT,ARDT,
            multi_vec=A.multi_vec,
            name="(N*$(A.name))"
        )
    end
end
function *(a::joNumber{ADDT,ARDT},A::joAbstractLinearOperator{ADDT,ARDT}) where {ADDT,ARDT}
    if hasinverse(A)
        return joLinearFunctionAll(A.m,A.n,
            v->a.rdt*(A*v),
            v->a.rdt*(transpose(A)*v),
            v->A'*(conj(a.rdt)*v),
            v->conj(a.rdt)*(conj(A)*v),
            v->(1/a.ddt)*(A\v),
            v->transpose(A)\((1/a.ddt)*v),
            v->A'\(1/conj(a.ddt)*v),
            v->(1/conj(a.ddt))*(conj(A)\v),
            ADDT,ARDT,
            name="(N*$(A.name))",
            multi_vec=A.multi_vec,
            inv_multi_vec=A.inv_multi_vec
        )
    else
        return joLinearFunctionCT(A.m,A.n,
            v->a.rdt*(A*v),
            v->a.rdt*(transpose(A)*v),
            v->A'*(conj(a.rdt)*v),
            v->conj(a.rdt)*(conj(A)*v),
            ADDT,ARDT,
            name="(N*$(A.name)",
            multi_vec=A.multi_vec
        )
    end
end

# *(jo,num)
*(A::joAbstractLinearOperator{ADDT,ARDT},a::Number) where {ADDT,ARDT} = a*A
*(A::joAbstractLinearOperator{ADDT,ARDT},a::joNumber{ADDT,ARDT}) where {ADDT,ARDT} = a*A

# +(jo)
+(A::joAbstractLinearOperator) = A

function -(A::joAbstractLinearOperator{DDT,RDT})  where {DDT,RDT}
        if hasinverse(A)
            return joLinearFunctionAll(A.m,A.n,
            v->-A.fop(v),
            v->-A.fop_T(v),
            v->-A.fop_CT(v),
            v->-A.fop_C(v),
            v->-A.iop(v),
            v->-A.iop_T(v),
            v->-A.iop(v),
            v->-A.iop_T(v),
            DDT,RDT,
            name="-$(A.name)",
            multi_vec=A.multi_vec,
            inv_multi_vec=A.inv_multi_vec
            )
        else
            return joLinearFunctionCT(A.m,A.n,
            v->-A.fop(v),
            v->-A.fop_T(v),
            v->-A.fop_CT(v),
            v->-A.fop_C(v),
            DDT,RDT,
            name="-$(A.name)",
            multi_vec=A.multi_vec,
            )        
        end
end

# +(jo,jo)
function +(A::joAbstractLinearOperator{DDT,RDT},B::joAbstractLinearOperator{DDT,RDT}) where {DDT,RDT}
    size(A) == size(B) || throw(joAbstractLinearOperatorException("shape mismatch"))
    return joLinearFunctionCT(size(A,1),size(B,2),
        v->A*v+B*v,
        v->transpose(A)*v+transpose(B)*v,
        v->A'*v+B'*v,
        v->conj(A)*v+conj(B)*v,
        DDT,RDT,
        name="($(A.name)+$(B.name)",
        multi_vec=(A.multi_vec & B.multi_vec),
        )
end

function +(A::joAbstractLinearOperator{ADDT,ARDT},b::Number) where {ADDT,ARDT}
    return joLinearFunctionCT(size(A,1),size(A,2),
        v->A*v+joConstants(A.m,A.n,b;DDT=ADDT,RDT=ARDT)*v,
        v->transpose(A)*v+joConstants(A.n,A.m,b;DDT=ARDT,RDT=ADDT)*v,
        v->A'*v+joConstants(A.n,A.m,conj(b);DDT=ARDT,RDT=ADDT)*v,
        v->conj(A)*v+joConstants(A.m,A.n,conj(b);DDT=ADDT,RDT=ARDT)*v,
        ADDT,ARDT,
        name="($(A.name) + N)",
        multi_vec = A.multi_vec
        )
end
function +(A::joAbstractLinearOperator{ADDT,ARDT},b::joNumber{ADDT,ARDT}) where {ADDT,ARDT}
    return joLinearFunctionCT(size(A,1),size(A,2),
        v->A*v+joConstants(A.m,A.n,b.rdt;DDT=ADDT,RDT=ARDT)*v,
        v->transpose(A)*v+joConstants(A.n,A.m,b.ddt;DDT=ARDT,RDT=ADDT)*v,
        v->A'*v+joConstants(A.n,A.m,conj(b.ddt);DDT=ARDT,RDT=ADDT)*v,
        v->conj(A)*v+joConstants(A.m,A.n,conj(b.rdt);DDT=ADDT,RDT=ARDT)*v,
        ADDT,ARDT,
        name="($(A.name) + N)",
        multi_vec = A.multi_vec
        )
end


+(b::Number,A::joAbstractLinearOperator{ADDT,ARDT}) where {ADDT,ARDT} = A+b
+(b::joNumber{ADDT,ARDT},A::joAbstractLinearOperator{ADDT,ARDT}) where {ADDT,ARDT} = A+b

-(A::joAbstractLinearOperator,B::joAbstractLinearOperator) = A+(-B)
-(A::joAbstractLinearOperator,b::Number) = A+(-b)
-(A::joAbstractLinearOperator,b::joNumber) = A+(-b)
-(b::Number,A::joAbstractLinearOperator) = -A+b
-(b::joNumber,A::joAbstractLinearOperator) = -A+b


# hcat(...jo...)
hcat(ops::joAbstractLinearOperator...) = joDict(ops...)

# vcat(...jo...)
vcat(ops::joAbstractLinearOperator...) = joStack(ops...)

# hvcat(...jo...)
hvcat(rows::Tuple{Vararg{Int}}, ops::joAbstractLinearOperator...) = joBlock(collect(rows),ops...)


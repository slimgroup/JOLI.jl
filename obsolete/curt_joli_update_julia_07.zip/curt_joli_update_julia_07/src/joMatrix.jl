############################################################
# joMatrix #################################################
############################################################

# includes
include("joMatrix/constructors.jl")
include("joMatrix/base_functions.jl")
include("joMatrix/extra_functions.jl")

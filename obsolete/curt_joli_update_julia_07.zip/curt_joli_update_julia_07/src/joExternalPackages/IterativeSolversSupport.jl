Adivtype(A::joAbstractLinearOperator{DDT,RDT}, b::AbstractVector) where {DDT,RDT} = DDT

# discarded Amultype{DDT,RDT}(A::joAbstractLinearOperator{DDT,RDT}, x::AbstractVector) = RDT


############################################################
## joLinearFunction - outer constructors

export joLinearFunctionAll, joLinearFunctionCT, joLinearFunctionFwd

# outer constructors

"""
joLinearFunction outer constructor

    joLinearFunctionAll(m::Integer,n::Integer,
        fop::Function,fop_T::Function,fop_CT::Function,fop_C::Function,
        iop::Function,iop_T::Function,iop_CT::Function,iop_C::Function,
        DDT::DataType,RDT::DataType=DDT;
        multi_vec::Bool=false,inv_multi_vec::Bool=false,
        name::String="joLinearFunctionAll")

Look up argument names in help to joLinearFunction type.

# Notes
- the developer is responsible for ensuring that used functions take/return correct DDT/RDT

"""
function joLinearFunctionAll(m::Integer,n::Integer,
    fop::Function,fop_T::Union{Function,Nothing},fop_CT::Union{Function,Nothing},fop_C::Union{Function,Nothing},
    iop::Union{Function,Nothing},iop_T::Union{Function,Nothing},iop_CT::Union{Function,Nothing},iop_C::Union{Function,Nothing},
    DDT::DataType,RDT::DataType=DDT;
    multi_vec::Bool=false,inv_multi_vec::Bool=false,
    name::String="joLinearFunctionAll") 
    return joLinearFunction{DDT,RDT}(name,m,n,
        multi_vec, inv_multi_vec,
        fop,fop_T,fop_CT,fop_C,
        iop,iop_T,iop_CT,iop_C
    )
end

function joLinearFunctionCT(m::Integer,n::Integer,
    fop::Function,fop_T::Union{Function,Nothing},fop_CT::Union{Function,Nothing},fop_C::Union{Function,Nothing},
    DDT::DataType,RDT::DataType=DDT;
    multi_vec::Bool=false,
    name::String="joLinearFunctionCT") 
    return joLinearFunction{DDT,RDT}(name,m,n,
        multi_vec, false,
        fop,fop_T,fop_CT,fop_C,
        @joNF,@joNF,@joNF,@joNF
    )
end

function joLinearFunctionFwd(m::Integer,n::Integer,
    fop::Function,fop_CT::Union{Function,Nothing},
    DDT::DataType,RDT::DataType=DDT;
    multi_vec::Bool=false,
    name::String="joLinearFunctionFwd") 
    return joLinearFunction{DDT,RDT}(name,m,n,
        multi_vec, false,
        fop,@joNF,fop_CT,@joNF,
        @joNF,@joNF,@joNF,@joNF
    )
end
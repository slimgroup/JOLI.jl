############################################################
## joMatrix - outer constructors

"""
joMatrix outer constructor

    joMatrix(array::AbstractMatrix;
             DDT::DataType=eltype(array),
             RDT::DataType=promote_type(eltype(array),DDT),
             name::String="joMatrix")

Look up argument names in help to joMatrix type.

# Example
- joMatrix(rand(4,3)) # implicit domain and range
- joMatrix(rand(4,3);DDT=Float32) # implicit range
- joMatrix(rand(4,3);DDT=Float32,RDT=Float64)
- joMatrix(rand(4,3);name="my matrix") # adding name

# Notes
- if DDT:<Real for complex matrix then imaginary part will be neglected for transpose/conjugated-transpose operator
- if RDT:<Real for complex matrix then imaginary part will be neglected for forward/conjugate operator

"""
function joMatrix(array::AbstractMatrix{EDT};
    DDT::DataType=EDT,RDT::DataType=promote_type(EDT,DDT),name::String="joMatrix",is_invertible::Bool=false) where {EDT}
    if is_invertible
        if size(array,1) != size(array,2)
            ldiv = v->array\v
            ldiv_transpose = v->transpose(array)\v
            ldiv_adjoint = v->adjoint(array)\v
            ldiv_conj = v->conj(array)\v
        else
            factorized_array = LinearAlgebra.factorize(array)
            ldiv = v->factorized_array\v
            ldiv_transpose = v->transpose(factorized_array)\v
            ldiv_adjoint = v->adjoint(factorized_array)\v
            ldiv_conj = v->conj(array)\v
        end
    else
        ldiv = @joNF
        ldiv_transpose = @joNF
        ldiv_adjoint = @joNF
        ldiv_conj = @joNF
    end
    return joMatrix{DDT,RDT}(name,size(array,1),size(array,2),
        array, true, true,
        v->jo_convert(RDT,array*v,false),
        v->jo_convert(DDT,transpose(array)*v,false),
        v->jo_convert(DDT,array'*v,false),
        v->jo_convert(RDT,conj(array)*v,false),
        ldiv,
        ldiv_transpose,
        ldiv_adjoint,
        ldiv_conj
        )
end

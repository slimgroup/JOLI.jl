
# conj(jo)
conj(A::joMatrix{DDT,RDT}) where {DDT,RDT} =
    joMatrix{DDT,RDT}("conj($(A.name))",A.m,A.n,
        conj(A.mat),
        true,
        true,
        A.fop_C,
        A.fop_CT,
        A.fop_T,
        A.fop,
        A.iop_C,
        A.iop_CT,
        A.iop_T,
        A.iop
        )
      
# transpose(jo)
transpose(A::joMatrix{DDT,RDT}) where {DDT,RDT} =
    joMatrix{RDT,DDT}("transpose($(A.name)",A.n,A.m,
        transpose(A.mat),
        true,
        true,
        A.fop_T,
        A.fop,
        A.fop_C,
        A.fop_CT,
        A.iop_T,
        A.iop,
        A.iop_C,
        A.iop_CT
        )

# adjoint(jo)
adjoint(A::joMatrix{DDT,RDT}) where {DDT,RDT} =
    joMatrix{RDT,DDT}("adjoint($(A.name))",A.n,A.m,
        adjoint(A.mat),
        true,
        true,
        A.fop_CT,
        A.fop_C,
        A.fop,
        A.fop_T,
        A.iop_CT,
        A.iop_C,
        A.iop,
        A.iop_T
        )
    
function -(A::joMatrix{DDT,RDT}) where {DDT,RDT} 
    if hasinverse(A)
        return joMatrix{RDT,DDT}("-$(A.name)",A.m,A.n,
        -A.mat,
        true,
        true,
        v->-A.fop(v),
        v->-A.fop_T(v),
        v->-A.fop_CT(v),
        v->-A.fop_C(v),
        v->-A.iop(v),
        v->-A.iop_T(v),
        v->-A.iop(v),
        v->-A.iop_T(v)
        )
    else
        return joMatrix{RDT,DDT}("-$(A.name)",A.m,A.n,
        -A.mat,
        true,
        true,
        v->-A.fop(v),
        v->-A.fop_T(v),
        v->-A.fop_CT(v),
        v->-A.fop_C(v),
        @joNF, @joNF, @joNF, @joNF
        )        
    end
end


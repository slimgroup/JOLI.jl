############################################################
# joNumber methods #########################################
############################################################

## constructors
"""
joNumber outer constructor

    joNumber(num)

Create joNumber with types matching given number

"""
joNumber(num::NT) where NT <: Number = joNumber{NT,NT}(num,num)
"""
joNumber outer constructor

    joNumber(num,A::joAbstractLinearOperator{DDT,RDT})

Create joNumber with types matching the given operator.

"""
joNumber(num::NT,A::joAbstractLinearOperator{DDT,RDT}) where {NT<:Number,DDT,RDT} =
    joNumber{DDT,RDT}(jo_convert(DDT,num),jo_convert(RDT,num))

## other functions
-(n::joNumber{DDT,RDT}) where {DDT,RDT} = joNumber{DDT,RDT}(-n.ddt,-n.rdt)
inv(n::joNumber{DDT,RDT}) where {DDT,RDT} = joNumber{DDT,RDT}(inv(n.ddt),inv(n.rdt))


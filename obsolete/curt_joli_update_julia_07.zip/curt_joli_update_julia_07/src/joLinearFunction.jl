############################################################
# joLinearFunction #########################################
############################################################

# includes
include("joLinearFunction/constructors.jl")
include("joLinearFunction/base_functions.jl")

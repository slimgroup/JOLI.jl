############################################################
# joAbstractFosterLinearOperator ####################
############################################################

# includes
include("joAbstractFosterLinearOperator/base_functions.jl")
include("joAbstractFosterLinearOperator/extra_functions.jl")

############################################################
# jo Types - miscellaneous constractors ####################
############################################################

############################################################
# includes
include("joTypesMiscMethods/joNumber.jl")
include("joTypesMiscMethods/joDAdistributor.jl")

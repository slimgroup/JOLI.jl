############################################################
# joAbstractOperator #######################################
############################################################

# includes
include("joAbstractOperator/base_functions.jl")
include("joAbstractOperator/extra_functions.jl")

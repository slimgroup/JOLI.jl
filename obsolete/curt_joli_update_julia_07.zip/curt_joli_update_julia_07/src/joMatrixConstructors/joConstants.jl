# matrix of constats

export joConstants
joConstants(m::Integer,a::EDT;DDT::DataType=EDT,RDT::DataType=promote_type(EDT,DDT)) where {EDT} = joConstants(m,m,a;DDT=DDT,RDT=RDT)
joConstants(m::Integer,n::Integer,a::EDT;DDT::DataType=EDT,RDT::DataType=promote_type(EDT,DDT)) where {EDT} =
    joLinearFunctionCT(m,n,
        v->a*ones(eltype(v),m,1)*sum(v,dims=1),
        v->a*ones(eltype(v),n,1)*sum(v,dims=1),
        v->conj(a)*ones(eltype(v),n,1)*sum(v,dims=1),
        v->conj(a)*ones(eltype(v),m,1)*sum(v,dims=1),
        DDT,RDT,
        name="joConstants",
        multi_vec=true
        )


# identity operators: joDirac

export joDirac
joDirac(m::Integer;DDT::DataType=joFloat,RDT::DataType=DDT) =
    joLinearFunctionAll(m,m,
        v->v,
        v->v,
        v->v,
        v->v,
        v->v,
        v->v,
        v->v,
        v->v,
        DDT,RDT,
        name="joDirac",multi_vec=true,inv_multi_vec
        )


############################################################
# jo Types #################################################
############################################################

############################################################
# includes
include("joTypes/joNumber.jl")
include("joTypes/joDAdistributor.jl")
include("joTypes/joAbstractOperator.jl")
include("joTypes/joAbstractFosterLinearOperator.jl")
include("joTypes/joAbstractLinearOperator.jl")
include("joTypes/joInplace.jl")
include("joTypes/joLinearOperator.jl")
include("joTypes/joMatrix.jl")
include("joTypes/joLinearFunction.jl")
include("joTypes/joCoreBlock.jl")
include("joTypes/joKron.jl")

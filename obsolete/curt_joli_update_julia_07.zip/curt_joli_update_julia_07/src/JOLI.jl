############################################################
# JOLI module ##############################################
############################################################

module JOLI

# what's being used
import LinearAlgebra
using DistributedArrays
using IterativeSolvers
using InplaceOps
using NFFT
using Printf
using SparseArrays

# what's imported from Base
import Base.eltype
import Base.show, Base.showall, Base.display
import Base.size, Base.length
import Base.full
import Base.real, Base.imag, Base.conj
import Base.transpose, Base.adjoint
import Base.isreal, LinearAlgebra.issymmetric, LinearAlgebra.ishermitian
import Base.*, Base.\, Base.+, Base.-
import Base.(.*), Base.(.\), Base.(.+), Base.(.-)
import Base.hcat, Base.vcat, Base.hvcat
import Base.inv
import LinearAlgebra.mul!

# what's imported from DistributedArrays
import DistributedArrays: DArray, distribute, dzeros, dones, dfill, drand, drandn

# what's imported from IterativeSolvers
import IterativeSolvers.Adivtype

# extra exported methods
export deltype, reltype
export elements, hasinverse, issquare, istall, iswide, iscomplex, islinear, isadjoint
export joLoosen

# constants
export joTol
global joTol = sqrt(eps())

# package for each operator code goes here
include("joTypes.jl")
include("joTypesMiscMethods.jl")
include("joUtils.jl")
include("joExternalPackages.jl")
include("joLinearFunction.jl")
include("joAbstractOperator.jl")
include("joAbstractLinearOperator.jl")
include("joAbstractFosterLinearOperator.jl")
include("joInplace.jl")
include("joMatrix.jl")
include("joMatrixConstructors.jl")
include("joLinearFunctionConstructors.jl")


end # module
